<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
if (!route(1)) {
    $route[1] = 'index';    
}

if (!file_exists(admin_controller(route(1)))) {
    $route[1] = 'index';
}

require admin_controller(route(1));