<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

define('PATH', realpath('.'));
define('SUBFOLDER', true);
define('URL', 'http://localhost:8888/gulrimas');

return [
    'db' => [
        'host'    => 'localhost',
        'dbname'  => 'gulrimas',
        'user'    => 'root',
        'pass'    => 'root'
    ]
];