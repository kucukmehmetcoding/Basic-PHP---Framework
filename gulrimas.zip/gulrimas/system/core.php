<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

session_start();
ob_start();

function loadClasses($className) {
    require __DIR__ . '/classes/' . strtolower($className) . '.php';
}

spl_autoload_register('loadClasses');

$config = require __DIR__.'/config.php';

try {
    $db = new PDO('mysql:host='. $config['db']['host'] . ';dbname='.$config['db']['dbname'],$config['db']['user'] , $config['db']['pass'] );
    
} catch (PDOException $exc) {
    die($exc->getMessage());
}

foreach (glob(__DIR__ . '/helpers/*.php') as $helperFile) {
    require $helperFile;
}

