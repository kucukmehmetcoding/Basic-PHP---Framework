<html>
    <head>
    <title>title</title>
</head>
<body>
    <h3>burası admin view sayfası</h3>
</body>
</html>
